<?php 
    namespace DAL; 
    use PDO; 

    class Conexao {
        private static $dbNome = 'esports_manager_db'; // ALTERADO: Nome do banco de dados para o tema de esports
        private static $dbHost = 'localhost';
        private static $dbUsuario = 'root'; 
        private static $dbSenha = ''; // Mantenha sua senha do DB, se houver
        
        private static $cont = null; 

        public static function conectar(){
            if (self::$cont == null){
                try{ 
                    self::$cont = new PDO("mysql:host=" . self::$dbHost . ";dbname=" . self::$dbNome,  self::$dbUsuario , self::$dbSenha); 
                    // Configurar para lançar exceções em caso de erro
                    self::$cont->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                }
                catch (\PDOException $exception) {
                    die ($exception->getMessage());
                }
            }
            return self::$cont; 
        }

        public static function desconectar (){
            self::$cont = null;
            return self::$cont;  // Embora retorne null, a intenção é limpar a conexão estática.
        }
    }
?>