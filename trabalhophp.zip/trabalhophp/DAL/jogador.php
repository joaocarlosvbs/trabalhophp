<?php

namespace DAL;

// Ajuste o caminho se o seu projeto "lpbccphp2025" estiver em um subdiretório diferente do document root
// ou se a estrutura de pastas for diferente.
include_once $_SERVER['DOCUMENT_ROOT'] . '/lpbccphp2025/DAL/conexao.php'; // Verifique este caminho
include_once $_SERVER['DOCUMENT_ROOT'] . '/lpbccphp2025/MODEL/Jogador.php'; // ALTERADO: para o modelo Jogador

// use DAL\Conexao; // Desnecessário se Conexao está no mesmo namespace e já incluído
// use MODEL\Jogador; // Desnecessário se vai usar \MODEL\Jogador explicitamente

class Jogador // ALTERADO: Nome da classe (era Aluno)
{
    public function Select()
    {
        $sql = "SELECT * FROM jogadores;"; // ALTERADO: tabela para 'jogadores'
        $con = Conexao::conectar();
        $registros = $con->query($sql);
        $con = Conexao::desconectar();

        $lstJogadores = []; // ALTERADO: nome da lista
        if ($registros) { // Verifica se a consulta retornou algo
            foreach ($registros as $linha) {
                $jogador = new \MODEL\Jogador(); // ALTERADO: para MODEL\Jogador
                $jogador->setId($linha['id']);
                $jogador->setNickname($linha['nickname']); // ALTERADO: campo
                $jogador->setNomeCompleto($linha['nome_completo']); // ADICIONADO: campo
                // Verifica se time_id e posicao_funcao existem e não são nulos antes de setar
                if (isset($linha['time_id']) && $linha['time_id'] !== null) {
                    $jogador->setTimeId($linha['time_id']); // ALTERADO: campo
                }
                if (isset($linha['posicao_funcao']) && $linha['posicao_funcao'] !== null) {
                    $jogador->setPosicaoFuncao($linha['posicao_funcao']); // ALTERADO: campo
                }
                $lstJogadores[] = $jogador; // ALTERADO: nome da lista
            }
        }
        return $lstJogadores;
    }

    public function SelectById(int $id)
    {
        $sql = "SELECT * FROM jogadores WHERE id=?;"; // ALTERADO: tabela
        $con = Conexao::conectar();
        $query = $con->prepare($sql);
        $query->execute(array($id));
        $linha = $query->fetch(\PDO::FETCH_ASSOC);
        $con = Conexao::desconectar();

        if (!$linha) { // Se nenhum jogador for encontrado
            return null; 
        }

        $jogador = new \MODEL\Jogador(); // ALTERADO: para MODEL\Jogador
        $jogador->setId($linha['id']);
        $jogador->setNickname($linha['nickname']); // ALTERADO: campo
        $jogador->setNomeCompleto($linha['nome_completo']); // ADICIONADO: campo
         if (isset($linha['time_id']) && $linha['time_id'] !== null) {
            $jogador->setTimeId($linha['time_id']); // ALTERADO: campo
        }
        if (isset($linha['posicao_funcao']) && $linha['posicao_funcao'] !== null) {
            $jogador->setPosicaoFuncao($linha['posicao_funcao']); // ALTERADO: campo
        }
        
        return $jogador;
    }

    /**
     * Insere um objeto Jogador no banco de dados.
     * ATENÇÃO: Convertido para usar Prepared Statements para evitar SQL Injection.
     */
    public function Insert(\MODEL\Jogador $jogador) // ALTERADO: tipo do parâmetro
    {
        // SQL Injection corrigido usando Prepared Statements
        $sql = "INSERT INTO jogadores (nickname, nome_completo, time_id, posicao_funcao) 
                VALUES (?, ?, ?, ?);"; // ALTERADO: tabela e colunas

        $con = Conexao::conectar();
        $query = $con->prepare($sql);
        
        // Obter os valores do objeto jogador
        // Usar null se o valor não estiver definido ou for explicitamente null no objeto Modelo
        // (assumindo que os getters retornam null se não definidos)
        $nickname = $jogador->getNickname();
        $nomeCompleto = $jogador->getNomeCompleto();
        $timeId = $jogador->getTimeId(); // Pode ser null se o jogador não estiver em um time
        $posicaoFuncao = $jogador->getPosicaoFuncao(); // Pode ser null

        $result = $query->execute(array($nickname, $nomeCompleto, $timeId, $posicaoFuncao));
        
        // Para obter o ID do último registro inserido, se a coluna 'id' for AUTO_INCREMENT
        // $lastId = $con->lastInsertId(); 
        
        $con = Conexao::desconectar();
        return $result;
    }

    /**
     * Atualiza um objeto Jogador no banco de dados.
     * Usa Prepared Statements.
     */
    public function Update(\MODEL\Jogador $jogador) // ALTERADO: tipo do parâmetro
    {
        $sql = "UPDATE jogadores SET nickname=?, nome_completo=?, time_id=?, posicao_funcao=? WHERE id = ?;"; // ALTERADO: tabela e colunas

        $con = Conexao::conectar();
        $query = $con->prepare($sql);

        // Obter os valores
        $nickname = $jogador->getNickname();
        $nomeCompleto = $jogador->getNomeCompleto();
        $timeId = $jogador->getTimeId();
        $posicaoFuncao = $jogador->getPosicaoFuncao();
        $id = $jogador->getId();

        $result = $query->execute(array($nickname, $nomeCompleto, $timeId, $posicaoFuncao, $id));
        $con = Conexao::desconectar();
        return $result;
    }

    public function Delete(int $id)
    {
        $sql = "DELETE FROM jogadores WHERE id = ?;"; // ALTERADO: tabela
        $con = Conexao::conectar();
        $query = $con->prepare($sql);
        $result = $query->execute(array($id));
        $con = Conexao::desconectar();
        return $result;
    }
}
?>