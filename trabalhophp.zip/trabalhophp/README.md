# lpbccphp2025
Projeto LP - Ciências da Computação
