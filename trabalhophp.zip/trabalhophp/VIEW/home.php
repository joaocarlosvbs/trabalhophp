<?php
  // O include do menu.php é mantido, assumindo que o menu também será adaptado ou é genérico.
  include_once $_SERVER['DOCUMENT_ROOT'] . "/lpbccphp2025/View/menu.php"; 
?>

<!DOCTYPE html>
<html lang="pt-BR"> <head>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <script src="/lpbccphp2025/view/js/init.js"></script> 

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial - Gerenciador de Esports</title> </head>

<body>
    <div class="container light-blue darken-3 white-text"> 

        <h1 class="center">GERENCIADOR DE ESPORTS</h1> <br />
        <div class="center-align">
            <img class="center" width="300" src="./images/esports_logo.webp" alt="Logo Esports"> 
            <br /> <br />
        </div>

    </div>
</body>

</html>