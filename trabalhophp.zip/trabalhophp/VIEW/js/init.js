(function($){
  $(function(){ // Equivalente a $(document).ready()

    // $('select').material_select(); // Linha comentada, método antigo do Materialize para selects
    $('select').formSelect(); // Método mais novo do Materialize para inicializar selects
    $('.sidenav').sidenav(); // Inicializa o componente de navegação lateral (sidenav)
    $('.parallax').parallax(); // Inicializa o efeito parallax em seções designadas
    $('.dropdown-trigger').dropdown(); // Inicializa menus dropdown
    
  }); // Fim do document ready
})(jQuery); // Fim do namespace jQuery