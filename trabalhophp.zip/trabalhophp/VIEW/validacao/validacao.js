//Validação simples
$("#formComentario").validate();