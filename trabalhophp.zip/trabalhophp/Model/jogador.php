<?php 
    namespace MODEL; // Mantendo o namespace do seu exemplo

    class Jogador {
        private ?int $id; 
        private ?string $nickname; 
        private ?string $nome_completo; 
        private ?int $time_id; // Chave estrangeira para a tabela Times
        private ?string $posicao_funcao; // Ex: "Entry Fragger", "Suporte", "Mid Laner"

        public function __construct()
        {
            // O construtor pode ser usado para inicializar valores padrão
            // ou para injetar dependências, como uma conexão com o banco, se necessário.
            // Por enquanto, deixaremos vazio como no seu exemplo.
        }

        // Getter e Setter para ID
        public function getId(): ?int {
            return $this->id; 
        }

        public function setId(int $id): void {
            $this->id = $id; 
        }

        // Getter e Setter para Nickname
        public function getNickname(): ?string {
            return $this->nickname; 
        }

        public function setNickname(string $nickname): void {
            $this->nickname = $nickname; 
        }

        // Getter e Setter para Nome Completo
        public function getNomeCompleto(): ?string {
            return $this->nome_completo; 
        }

        public function setNomeCompleto(string $nome_completo): void {
            $this->nome_completo = $nome_completo; 
        }

        // Getter e Setter para Time ID
        public function getTimeId(): ?int {
            return $this->time_id; 
        }

        public function setTimeId(int $time_id): void {
            $this->time_id = $time_id; 
        }

        // Getter e Setter para Posição/Função
        public function getPosicaoFuncao(): ?string {
            return $this->posicao_funcao; 
        }

        public function setPosicaoFuncao(string $posicao_funcao): void {
            $this->posicao_funcao = $posicao_funcao; 
        }
    }

?>