-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03/06/2025 às 19:30 (Exemplo de Data)
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `esports_manager_db`
--
CREATE DATABASE IF NOT EXISTS `esports_manager_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `esports_manager_db`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios_admin` (Para o requisito de login)
--
DROP TABLE IF EXISTS `usuarios_admin`;
CREATE TABLE `usuarios_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL COMMENT 'Senha armazenada com hash seguro'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios_admin`
--
INSERT INTO `usuarios_admin` (`id`, `username`, `password_hash`) VALUES
(1, 'admin', '$2y$10$exampleHashValueForTheAdminUser123'); -- Substitua por um hash real

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogos_esport` (Similar a 'livro' no seu exemplo)
--
DROP TABLE IF EXISTS `jogos_esport`;
CREATE TABLE `jogos_esport` (
  `id` int(11) NOT NULL,
  `nome_jogo` varchar(100) NOT NULL,
  `desenvolvedora` varchar(100) DEFAULT NULL,
  `genero_jogo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `jogos_esport`
--
INSERT INTO `jogos_esport` (`id`, `nome_jogo`, `desenvolvedora`, `genero_jogo`) VALUES
(1, 'Counter-Strike 2', 'Valve/Hidden Path Entertainment', 'FPS'),
(2, 'League of Legends', 'Riot Games', 'MOBA'),
(3, 'Valorant', 'Riot Games', 'FPS');

-- --------------------------------------------------------

--
-- Estrutura para tabela `times`
--
DROP TABLE IF EXISTS `times`;
CREATE TABLE `times` (
  `id` int(11) NOT NULL,
  `nome_time` varchar(100) NOT NULL,
  `sigla_time` varchar(10) DEFAULT NULL,
  `jogo_principal_id` int(11) DEFAULT NULL COMMENT 'FK para jogos_esport',
  `pais_origem` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `times`
--
INSERT INTO `times` (`id`, `nome_time`, `sigla_time`, `jogo_principal_id`, `pais_origem`) VALUES
(1, 'LOUD', 'LLL', 3, 'Brasil'),
(2, 'FaZe Clan', 'FaZe', 1, 'Estados Unidos'),
(3, 'T1', 'T1', 2, 'Coreia do Sul'),
(4, 'FURIA Esports', 'FUR', 1, 'Brasil');


-- --------------------------------------------------------

--
-- Estrutura para tabela `jogadores` (Similar a 'aluno' no seu exemplo)
--
DROP TABLE IF EXISTS `jogadores`;
CREATE TABLE `jogadores` (
  `id` int(11) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `nome_completo` varchar(100) DEFAULT NULL,
  `time_id` int(11) DEFAULT NULL COMMENT 'FK para times',
  `posicao_funcao` varchar(50) DEFAULT NULL COMMENT 'Ex: AWPer, Suporte, Duelista'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `jogadores`
--
INSERT INTO `jogadores` (`id`, `nickname`, `nome_completo`, `time_id`, `posicao_funcao`) VALUES
(1, 'aspas', 'Erick Santos', 1, 'Duelista'),
(2, 'FalleN', 'Gabriel Toledo', 4, 'AWPer/Capitão'),
(3, 'Faker', 'Lee Sang-hyeok', 3, 'Mid Laner'),
(4, 'karrigan', 'Finn Andersen', 2, 'Capitão/IGL');

-- --------------------------------------------------------

--
-- Estrutura para tabela `partidas` (Similar a 'emprestimo' no seu exemplo)
--
DROP TABLE IF EXISTS `partidas`;
CREATE TABLE `partidas` (
  `id` int(11) NOT NULL,
  `time_casa_id` int(11) NOT NULL COMMENT 'FK para times',
  `time_visitante_id` int(11) NOT NULL COMMENT 'FK para times',
  `jogo_id` int(11) NOT NULL COMMENT 'FK para jogos_esport',
  `data_hora_partida` datetime NOT NULL,
  `resultado_time_casa` int(11) DEFAULT NULL,
  `resultado_time_visitante` int(11) DEFAULT NULL,
  `status_partida` varchar(20) NOT NULL DEFAULT 'Agendada' COMMENT 'Ex: Agendada, Em Andamento, Concluida, Cancelada'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `partidas`
--
INSERT INTO `partidas` (`id`, `time_casa_id`, `time_visitante_id`, `jogo_id`, `data_hora_partida`, `resultado_time_casa`, `resultado_time_visitante`, `status_partida`) VALUES
(1, 1, 4, 3, '2025-06-10 14:00:00', NULL, NULL, 'Agendada'),
(2, 2, 4, 1, '2025-06-01 18:00:00', 2, 1, 'Concluida'),
(3, 3, 1, 2, '2025-06-15 20:00:00', NULL, NULL, 'Agendada');


--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `usuarios_admin`
--
ALTER TABLE `usuarios_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Índices de tabela `jogos_esport`
--
ALTER TABLE `jogos_esport`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `times`
--
ALTER TABLE `times`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome_time` (`nome_time`),
  ADD KEY `idx_time_jogo_principal` (`jogo_principal_id`);

--
-- Índices de tabela `jogadores`
--
ALTER TABLE `jogadores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nickname` (`nickname`),
  ADD KEY `idx_jogador_time` (`time_id`);

--
-- Índices de tabela `partidas`
--
ALTER TABLE `partidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_partida_time_casa` (`time_casa_id`),
  ADD KEY `idx_partida_time_visitante` (`time_visitante_id`),
  ADD KEY `idx_partida_jogo` (`jogo_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `usuarios_admin`
--
ALTER TABLE `usuarios_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `jogos_esport`
--
ALTER TABLE `jogos_esport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `times`
--
ALTER TABLE `times`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `jogadores`
--
ALTER TABLE `jogadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `partidas`
--
ALTER TABLE `partidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `times`
--
ALTER TABLE `times`
  ADD CONSTRAINT `fk_time_jogo_principal` FOREIGN KEY (`jogo_principal_id`) REFERENCES `jogos_esport` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Restrições para tabelas `jogadores`
--
ALTER TABLE `jogadores`
  ADD CONSTRAINT `fk_jogador_time` FOREIGN KEY (`time_id`) REFERENCES `times` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Restrições para tabelas `partidas`
--
ALTER TABLE `partidas`
  ADD CONSTRAINT `fk_partida_jogo` FOREIGN KEY (`jogo_id`) REFERENCES `jogos_esport` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_partida_time_casa` FOREIGN KEY (`time_casa_id`) REFERENCES `times` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_partida_time_visitante` FOREIGN KEY (`time_visitante_id`) REFERENCES `times` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;